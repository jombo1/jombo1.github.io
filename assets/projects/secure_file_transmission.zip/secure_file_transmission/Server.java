import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class Server {
	@SuppressWarnings({ "resource" })
	public static void main(String[] args) throws IOException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException {
		
		//Initialize Stuff
		int ivSize = 16;
		Cipher rsaCipher, aesCipher;
		int port = 12345;
		ServerSocket welcomeSocket = new ServerSocket(port);
		System.out.println("Server started and is listening to the port " + port);
		
		//https://www.novixys.com/blog/how-to-generate-rsa-keys-java/
		//Generate Keys, saved in pub and pvt
		KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
		kpg.initialize(2048);
		KeyPair kp = kpg.generateKeyPair();
		Key pub = kp.getPublic();
		Key pvt = kp.getPrivate();
		System.out.println("Keypairs generated");
		
		System.out.println("Public key length: " + pub.getEncoded().length 
				+ "\nPrivate key length: " + pvt.getEncoded().length
				+ "\n");

		//Connecting
		while(true){
			Socket connectionSocket = welcomeSocket.accept();
			
			DataOutputStream outToClient = new DataOutputStream(connectionSocket.getOutputStream());

			//Get length and encoded byte array of public key
			int pubEncodedLength = pub.getEncoded().length;
			byte[] pubEncoded = pub.getEncoded();
			
			//Send public key length and key to client
			outToClient.writeInt(pubEncodedLength);
			outToClient.write(pubEncoded);
			System.out.println("Public key sent to client");
			
			DataInputStream inFromClient = new DataInputStream(connectionSocket.getInputStream());

			//Get ciphered secret key from client
        	int inLength = inFromClient.readInt();
        	System.out.println("Client reported secret key length: " + inLength);
        	byte[] cipheredSecretKey = new byte[inLength];
        	inFromClient.readFully(cipheredSecretKey);
        	System.out.println("Secret key recieved from client \nRecieved secret key length: " 
        			+ cipheredSecretKey.length);

        	//Decrypt secret key, store it to skey
        	rsaCipher = Cipher.getInstance("RSA");
        	rsaCipher.init(Cipher.DECRYPT_MODE, pvt);
        	SecretKeySpec skey = new SecretKeySpec(rsaCipher.doFinal(cipheredSecretKey), "AES");
        	System.out.println("Secret key decrypted");
        	
        	//Get ciphered message from client
        	inLength = inFromClient.readInt();
        	System.out.println("Client reported message length: " + inLength);
        	byte[] clientMessageAndIv = new byte[inLength];
        	inFromClient.readFully(clientMessageAndIv);
        	System.out.println("Message recieved from client \nRecieved message length: " 
        			+ clientMessageAndIv.length);
        	
        	//Retrieve IV
        	byte[] iv = new byte[ivSize];
        	System.arraycopy(clientMessageAndIv, 0, iv, 0, iv.length);
        	IvParameterSpec ivspec = new IvParameterSpec(iv);
        	
        	//Retrieve encrypted part
        	int encryptedSize = clientMessageAndIv.length - ivSize;
            byte[] encryptedMessage = new byte[encryptedSize];
            System.arraycopy(clientMessageAndIv, ivSize, encryptedMessage, 0, encryptedSize);
        	
        	//Decrypt message
        	aesCipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        	aesCipher.init(Cipher.DECRYPT_MODE, skey, ivspec);
        	byte[] decryptedMessage = aesCipher.doFinal(encryptedMessage);
        	String decryptedMessage2str = new String(decryptedMessage);
        	System.out.println("Message Decrypted");
        	
        	System.out.println("Message recieved:\n------------\n" + decryptedMessage2str + "\n------------");

        	//Save to File
        	PrintWriter out = new PrintWriter("final.txt");
        	out.println(decryptedMessage2str);
        	out.close();
        	System.out.println("Message saved to final.txt");
        	
        	//Send OK to sender
        	String ok = "OK, message sent and saved to final.txt";
        	int oklength = ok.length();
        	outToClient.writeInt(oklength);
        	outToClient.write(ok.getBytes());
        	
		}

	}

}

import java.net.Socket;
import java.net.UnknownHostException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.util.Scanner;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.SecureRandom;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKeyFactory;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class Client {
	
	@SuppressWarnings({ })
	public static void main(String[] args) throws NoSuchAlgorithmException, InvalidKeySpecException, UnknownHostException, IOException, InvalidKeyException, InvalidAlgorithmParameterException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException {
		
		//Initialize Stuff
		Cipher rsaCipher, aesCipher;
		Scanner inputFile = null;
		rsaCipher = Cipher.getInstance("RSA");
		
		//Get user input
		Scanner reader = new Scanner(System.in); 
		
		System.out.println("Enter the name of your file: ");
		String filename = reader.nextLine();
		System.out.println("Enter your password: ");
		String password = reader.nextLine();
		
		//save the file the user inputed into a scanner
		File file = new File(filename);
		try {
			inputFile = new Scanner(file);
		} catch (FileNotFoundException e) {
			System.out.println("File not found! Please start over.");
			System.exit(1);
		}
		reader.close();
		
		
		//Create initialization vector
		int ivSize = 16;
        byte[] iv = new byte[ivSize];
        SecureRandom random = new SecureRandom();
        random.nextBytes(iv);
        IvParameterSpec ivspec = new IvParameterSpec(iv);
        System.out.println("\nIV Created");
		
        //Create secretKey
        //https://www.novixys.com/blog/aes-encryption-decryption-password-java/
        byte[] salt = new byte[8];
		new SecureRandom().nextBytes(salt);
        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        KeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 10000, 128);
        SecretKey tmp = factory.generateSecret(spec);
        SecretKeySpec skey = new SecretKeySpec(tmp.getEncoded(), "AES");
        System.out.println("Secret key created");
        
		//Connect to socket
		String host = "localhost";
		int port = 12345;
		Socket clientSocket = new Socket(host, port); 
		System.out.println("Connected to " + host + " on port " + port);
		DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream()); 
		DataInputStream inFromServer = new DataInputStream(clientSocket.getInputStream());

		// Read public key from server
		int pubLength = inFromServer.readInt();
		System.out.println("Server reported public key length: " + pubLength);
		byte[] pubKey = new byte[pubLength];
		inFromServer.readFully(pubKey);
		System.out.println("Public key recieved from server"
						+ "Recieved public key length: " + pubKey.length);
		
		//Create public key from pubKey for secret key
		PublicKey publicKey = 
				KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(pubKey));
		
		//Initialize the cipher secret key
        rsaCipher.init(Cipher.ENCRYPT_MODE, publicKey);
        
        //Encrypt the secret key and store it in a byte array
        byte[] cipheredSecretKey = rsaCipher.doFinal(skey.getEncoded());
        int cipheredSecretKeyLength = cipheredSecretKey.length;
        
        //Send secret key to server
        outToServer.writeInt(cipheredSecretKeyLength);
        outToServer.write(cipheredSecretKey);
        System.out.println("Secret key sent to server encrypted with public key");
        
        //Stores scanner into a string 
        String inputFile2str = "";
        while (inputFile.hasNextLine())
        	inputFile2str = inputFile2str.concat(inputFile.nextLine() + "\n");
       
        //Initialize AES Cipher for message
        aesCipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        aesCipher.init(Cipher.ENCRYPT_MODE, skey, ivspec);
        //Encrypt the message and store it in a byte array
        byte[] cipheredMessage = aesCipher.doFinal(inputFile2str.getBytes());
        
        //Combine ciphered message and IV into a single byte array
        byte[] messageAndIv = new byte[ivSize + cipheredMessage.length];
        System.arraycopy(iv, 0, messageAndIv, 0, ivSize);
        System.arraycopy(cipheredMessage, 0, messageAndIv, ivSize, cipheredMessage.length);
        
        //Send ciphered message to server
        int cipheredMessageLength = messageAndIv.length;
        outToServer.writeInt(cipheredMessageLength);
        outToServer.write(messageAndIv);
        System.out.println("Message length: " + cipheredMessageLength + "\nMessage sent to server encrypted with AES/CBC/PKCS5Padding");
        
        System.out.println("Message sent:\n------------\n" + inputFile2str + "\n------------");
        
        //Receive OK from receiver
        int oklength = inFromServer.readInt();
        byte[] okbytes = new byte[oklength];
        inFromServer.readFully(okbytes);
        String ok = new String(okbytes);
        System.out.println(ok);
        
        clientSocket.close();
        
	}

}

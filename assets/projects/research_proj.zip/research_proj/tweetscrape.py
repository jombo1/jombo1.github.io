import requests
import time
import datetime
from bs4 import BeautifulSoup
from cassandra.cluster import Cluster

i=1
starttime = time.time()
while True:
	cluster = Cluster()
	session = cluster.connect('twitter')

	page = requests.get("https://twitter.com/ericbolling/status/981520242856914944")

	soup = BeautifulSoup(page.content, 'html.parser')

	stat_favorites = soup.find(class_="js-stat-count js-stat-favorites stat-count")
	stat_retweets = soup.find(class_="js-stat-count js-stat-retweets stat-count")
	stat_screenName = soup.find(class_="username u-dir u-textTruncate")
	stat_tweetText = soup.find(class_="TweetTextSize TweetTextSize--jumbo js-tweet-text tweet-text")

	# print(stat_screenName.prettify())

	ts = time.time()
	st = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')

	numFavorites = stat_favorites.find(class_="request-favorited-popup").get_text().replace('Likes','').replace('\n','').replace(',','').replace(' ','')
	numRetweets = stat_retweets.find(class_="request-retweeted-popup").get_text().replace('Retweets','').replace('\n','').replace(',','').replace(' ','')

	screenName = stat_screenName.getText()
	tweetText = stat_tweetText.getText()
	print(screenName + '\n-----------\n' + tweetText + '\n-----------\nF: ' + numFavorites + '\nR: ' +  numRetweets + '\nI: ' + str(i) + '\n\n')

	query = "INSERT INTO tweet4(retweets,favorites,insertion_time) values ('{0}','{1}','{2}')".format(numRetweets,numFavorites,st)
	session.execute(query)

	cluster.shutdown()
	session.shutdown()
	
	time.sleep(1800.0 - ((time.time() - starttime) % 1800.0))
	i=i+1
